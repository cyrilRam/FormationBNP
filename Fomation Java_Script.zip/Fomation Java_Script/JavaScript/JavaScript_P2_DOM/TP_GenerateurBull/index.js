const counterDisplay = document.querySelector("h3");
let counter = 0;

/*on crée la fonction qui génère une bulle*/
const bubbleMaker=()=>{
    const bubble=document.createElement("span"); /*injecter une balise comme le iner HTML*/
    bubble.classList.add("bubble"); /*ajout de la class css*/
    document.body.appendChild(bubble); /*injecter dans le body la variable buuble*/
    
    /*Pour voir la buuble sur l'ecran il faut lui def une taille qui sera random entre 100 et 200px
    Apres avoir mis la taille dans une variable ou va ajouter du style a la classe
    On va la mettre a une position aleatoire*/
    const size = Math.random() * 200 + 100 + "px";
    bubble.style.height = size;
    bubble.style.width = size;
    bubble.style.top = Math.random() * 100 + 50 + "%";
    bubble.style.left = Math.random() * 100 + "%";
    /*on va injecter une valeur à la variable --left de css*/
    const plusMinus = Math.random() > 0.5 ? 1 : -1; /*si rand >0.5 alors tu donnes 1 sinon -1 => pour que les bulles se decalent a gauche ou a droite*/
    bubble.style.setProperty("--left", Math.random() * 100 * plusMinus + "%");

    /*apres un certain temps on supprime la bulle : Timer apres un certain temps tu fais ca*/
    setTimeout(()=>{
        bubble.remove();
    },8000); //dans 8secondes tu degages
    
    /*ajouter un evenement quand on clique dessus, quand je clique sur l'element represente par la variable bubble alors ...*/
    bubble.addEventListener('click',()=>{
        counterDisplay.textContent = counter;
        counter++;
        bubble.remove();
    })

    /*compter le nombre de bull sur lequel on a cliqué*/
};

/*jouer quelque chose selon un intervale de temps*/
setInterval(bubbleMaker,1000);


