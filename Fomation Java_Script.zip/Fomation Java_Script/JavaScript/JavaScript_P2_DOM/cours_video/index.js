//   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      Les selecteurs  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// document.querySelector("h4").style.background="yellow";
// const baliseHTML = document.querySelector("H4");



//   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      Click Event  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
const questionContainer=document.querySelector(".click-event");
//Les 2 methodes font la meme chose
const bt1=document.querySelector("#btn-1");
const bt2=document.getElementById("btn-2");
const answer=document.querySelector("p");

console.log(bt1,bt2);

//on oeut aussi faire onclick mais plus bcp utilisé
questionContainer.addEventListener('click',()=>{
    //toujours faire un console log avant

    //j'ajoute la classe qui vient CSS qui s'appelle question-clicked
    //toogle ca permet de si la classe est deja presente on la retire si pas alors on l'ajoute
    questionContainer.classList.toggle("question-click");
});

bt1.addEventListener('click',()=>{
    answer.classList.add("show-answer");
    answer.style.background="green";
})

bt2.addEventListener('click',()=>{
    answer.style.background="red";
})



//   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      Mouse Event  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

const mousemove=document.querySelector(".mousemove");

//chaque fois que l'evenemnt se produit on peut recup l'evenemnt, tout ce qui s'est passé, locilisation ..

//Ici on veut faire suivre le cercle sur la souris, on ne se met pas sur le doc mais sur la window
window.addEventListener('mousemove',(e)=>{
    mousemove.style.left=e.pageX +"px";
    mousemove.style.top=e.pageY +"px";
  
})

//Quand on fait scrole vers le bas
window.addEventListener("mousedown",()=>{
    console.log("test");
})

window.addEventListener("mousedown", () => {
    mousemove.style.transform = "scale(2) translate(-25%, -25%)";
  });
  
  window.addEventListener("mouseup", () => {
    mousemove.style.transform = "scale(1) translate(-50%, -50%)";
    mousemove.style.border = "2px solid teal";
  });
  
  //quand la souris survolde la box de la question
  questionContainer.addEventListener("mouseenter", () => {
    questionContainer.style.background = "rgba(0,0,0,0.6)";
  });
  
  //quand elle y sort
  questionContainer.addEventListener("mouseout", () => {
    questionContainer.style.background = "pink";
  });
  
  // Quand je survole la reponse ca penche
  answer.addEventListener("mouseover", () => {
    answer.style.transform = "rotate(2deg)";
  });



//   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      KeyPress %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

const keypressContainer = document.querySelector(".keypress");
const key = document.getElementById("key");

//Sonnette
// Fonction qui va sonner 
const ring = (key) => {
  const audio = new Audio();
  audio.src = key + ".mp3";
  audio.play();
};

document.addEventListener("keypress", (e) => {
  key.textContent = e.key;

  if (e.key === "j") {
    keypressContainer.style.background = "pink";
  } else if (e.key === "h") {
    keypressContainer.style.background = "teal";
  } else {
    keypressContainer.style.background = "red";
  }
  if (e.key === "z") ring(e.key); //car l'audio s'appelle z.MP3
});



//   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      Scroll %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

// Quand on a scroll un certain nb de pixel tu sors la nav bar
const nav = document.querySelector("nav");

window.addEventListener("scroll", () => {
  if (window.scrollY > 120) {
    nav.style.top = 0;
  } else {
    nav.style.top = "-50px";
  }
});



//   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Form Event %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
const inputName = document.querySelector('input[type="text"]');
const select = document.querySelector("select");
const form = document.querySelector("form");
let pseudo = "";
let language = "";

//on recupere dans pseudo ce qy'on a tapé
inputName.addEventListener("input", (e) => {
  pseudo = e.target.value;
});

select.addEventListener("input", (e) => {
  language = e.target.value;
});

//Quand je clique sur valider
form.addEventListener("submit", (e) => {
  e.preventDefault();

  //cgv c'est l'id du checkbox
  if (cgv.checked) {
    //si c'est checked on veut afficher dans la divison vide que l'on avait mis dans le form
    //dans form tu vas me chercher l'enfant qui s'appelle div
    //innerHTML ca sert ca rajoute des balises dans le code
    document.querySelector("form > div").innerHTML = `
      <h3>Pseudo : ${pseudo}</h3>
      <h4>Langage préféré : ${language}</h4>
    `;
  } else {
    alert("Veuillez accepter les CGV");
  }
});

//   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  LOAD EVENT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//Pour les charger a la tt fin si ils sont lourds -> une fois que le doc est chargé
//Pas mal aussi si on veut charger des choses a ouverture page 

// Load event
window.addEventListener("load", () => {
    // console.log("Document Chargé !");
  });

//   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  FOREACH %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// Pour plusieurs elements qui ont la meme classe
//Par exemple on a 3 boites box et si on veut select tous ces elements

// const boxes = document.getElementsByClassName("box");
const boxes = document.querySelectorAll(".box");

//Des que je clique ca baisse la taille
boxes.forEach((box) => {
  box.addEventListener("click", (e) => {
    box.style.transform = "scale(0.7)";
  });
});

//   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% STop poropagantiojn %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// ca arrete les autres evenements du code

// questionContainer.addEventListener("click", (e) => {
    //   alert("Test !");
    //   e.stopPropagation();
    // });


//   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Browser Objet Model BOM : Partie Window %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//Ouvrir un opo up -> exemple pour rediriger sur un formulaire
// window.open("http://google.com", "cours js", "height=600, width=800");
// window.close(); //fermer la fenetre

//%%%%%%%% Evenements asoscies a window %%%%%%%%%%%%%%

//alert(Hello)

// confirm -> pour lui demander s'il veut vraiment faire ca
    // Si je fais pk 
    bt2.addEventListener("click", () => {
        confirm("Voulez vous vraiment vous tromper ?");
    });

    //prompt -> Attend une reponse et la reponse on peut la stocker dans ne variable
    bt1.addEventListener("click", () => {
        let answer = prompt("Entrez votre nom !"); //stocke dans answer -> ca va etre pas pouvoir etre recup  en dehors la valeur e answer
    
        questionContainer.innerHTML += "<h3>Bravo " + answer + "</h3>"; //vient mettre le H3 dans la di
    });

// Timer, compte à rebours
    //setTimeOut (logique a excuter, temps en millisecond)
    // Tu fais ca au bout de 2 secondes
    setTimeout(() => {
        questionContainer.style.borderRadius = "300px";
    }, 2000);


    //Set Interval -> pour faire choses a des intervals de temps, Toutes les 4 secondes ca rajoute une boite
            // let interval = setInterval(() => {
            //   document.body.innerHTML += `
            //       <div class='box'>
            //         <h2>Nouvelle Boite !</h2>
            //       </div>
            //     `;
            // }, 4000);


//retire l'élement sur lequel on clique        
    document.body.addEventListener("click", (e) => {
        e.target.remove();
        clearInterval(interval);
        });

//%%%%%%%% Location : Analyser ou rediriger %%%%%%%%%%%%%%

// console.log(location.href);
// console.log(location.host);
// console.log(location.pathname);
// console.log(location.search);
// location.replace("http://lequipe.fr"); //remplace par le site de l'équipe, rediriger vers un autre lien

// //Pour envoyer vers un autre site : 
// window.onload = () => {
//   location.href = "http://twitter.fr";
// };

//%%%%%%%% Navigatore : identifer le navigateur dans lequel on est  %%%%%%%%%%%%%%

// console.log(navigator.userAgent); -<Renvoie les infos

//Peremet de nous localiser : doc -> https://developer.mozilla.org/fr/docs/Web/API/Geolocation/getCurrentPosition
    // var options = {
    //   enableHighAccuracy: true,
    //   timeout: 5000,
    //   maximumAge: 0,
    // };

    // function success(pos) {
    //   var crd = pos.coords;

    //   console.log("Votre position actuelle est :");
    //   console.log(`Latitude : ${crd.latitude}`);
    //   console.log(`Longitude : ${crd.longitude}`);
    //   console.log(`La précision est de ${crd.accuracy} mètres.`);
    // }

    // function error(err) {
    //   console.warn(`ERREUR (${err.code}): ${err.message}`);
    // }

    // navigator.geolocation.getCurrentPosition(success, error, options);

//%%%%%%%% Historique : recuperer les données de l'histo %%%%%%%%%%%%%%
    // console.log(history);
    // window.history.back(); ->retour en arrière
    // history.go(-2)


//   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Set Propriety %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// SetProperty
//vient prendre les var --x et --y de css, on veut que ca suive la souris quand on est dans nav
    // window.addEventListener("mousemove", (e) => {
    //     nav.style.setProperty("--x", e.layerX + "px");
    //     nav.style.setProperty("--y", e.layerY + "px");
    // });