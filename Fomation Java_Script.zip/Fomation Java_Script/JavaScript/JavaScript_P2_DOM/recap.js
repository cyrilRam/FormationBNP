
// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Click EVent %%%%%%%%%%%%%%%%%%%%%%%%%%%%
//quand je clique sur ce bouton une action se passe
const bt1=document.querySelector("#btn-1");
const bt2=document.getElementById("btn-2");
bt1.addEventListener('click',()=>{
    answer.classList.add("show-answer");
    answer.style.background="green";
})
bt2.addEventListener('click',()=>{
    answer.style.background="red";
})

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Creaction fonction + action touche %%%%%%%%%%%%%%%%%%%%%%%%%%%%

//quand je clique sur une touche ca déclenche une fonction
const keypressContainer = document.querySelector(".keypress");
const key = document.getElementById("key"); //c'est un id dans le html

// Fonction qui va sonner 
const ring = (key) => {
  const audio = new Audio();
  audio.src = key + ".mp3";
  audio.play();
};

//si tape j alors rose, h teal et sinon rouge
document.addEventListener("keypress", (e) => {
  key.textContent = e.key;

  if (e.key === "j") {
    keypressContainer.style.background = "pink";
  } else if (e.key === "h") {
    keypressContainer.style.background = "teal";
  } else {
    keypressContainer.style.background = "red";
  }
  if (e.key === "z") ring(e.key); //car l'audio s'appelle z.MP3
});

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Formulaire %%%%%%%%%%%%%%%%%%%%%%%%%%%%

//%%%%%%% recuperer INPUT %%%%%%

const inputName = document.querySelector('input[type="text"]');
let pseudo = ""; //variable qui stocke l'input
const select = document.querySelector("select");
let language = ""; 
const form = document.querySelector("form");

//on recupere dans pseudo ce qu'on tape en temps réel
inputName.addEventListener("input", (e) => {
  pseudo = e.target.value;
});
//on recupere ce qui a été submit
select.addEventListener("input", (e) => {
  language = e.target.value;
});

//%%%%%%%%%% Validation Form %%%%%%%%%%
form.addEventListener("submit", (e) => {
  e.preventDefault(); //en faisant ceci on annule le changement de page et donc la disparition du formulaire

  //cgv c'est l'id du checkbox
  if (cgv.checked) {
    //si c'est checked on veut afficher dans la divison vide que l'on avait mis dans le form du html
    //dans form tu vas me chercher l'enfant de form qui s'appelle div
    //innerHTML ca sert ca rajoute des balises dans le code
    //On ajoute la valeur de la variable pseudo
    document.querySelector("form > div").innerHTML = `
      <h3>Pseudo : ${pseudo}</h3> 
      <h4>Langage préféré : ${language}</h4>
    `;
  } else {
    alert("Veuillez accepter les CGV");
  }
});