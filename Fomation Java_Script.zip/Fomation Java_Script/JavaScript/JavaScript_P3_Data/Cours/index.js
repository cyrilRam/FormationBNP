//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Rappel des données %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

let string = "Chaine";
let number = 25;
let boolean = true;
let maVariable; // type Undefined

// Tableaux
let array = ["Bordeaux", "Toulouse", "Nantes"];
// console.log(array[0][3]); =>lettre d de bordeaux

let array2 = ["Bordeaux", 24, true, [1, 2], { nom: "Denis" }];
// console.log(array2[4].nom);

let objet = {
  pseudo: "Denis",
  age: 33,
  technos: ["Javascript", "React", "NodeJs"],
  admin: false,
};

// objet.adresse = "22 rue du code"; => j'ajoute l'adresse de l'user à l'obejt
// console.log(objet);

let data = [
  {
    pseudo: "Denis",
    age: 33,
    technos: ["Javascript", "React", "NodeJs"],
    admin: false,
  },
  {
    pseudo: "Samia",
    age: 24,
    technos: ["CSS", "React", "NodeJs"],
    admin: false,
  },
  {
    pseudo: "Nikola",
    age: 42,
    technos: ["Php", "React", "NodeJs"],
    admin: true,
  },
];

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Structure de controles %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (data[0].age > data[1].age) {
  // console.log(data[0].pseudo + " est plus agé que " + data[1].pseudo);
} else {
  // Valeur si faux
}

// While
let w = 0;

while (w < 10) {
  w++;
  // console.log("La valeur de w est de : " + w);
}

// Do while
let d = 0;

do {
  d++;
  // console.log(d);
} while (d < 5);

// Les boucles for each
for (const user of data) {
  // document.body.innerHTML += `<li>${user.pseudo} - ${user.age} ans</li>`;
}

// on déclare la valeur de i | jusqu'où on boucle | on incrémente i si la condition 2 n'est pas remplie
for (i = 0; i < data.length; i++) {
  // console.log(i);
  // console.log(data[i].technos[0]);
  // document.body.innerHTML += "<h2>" + data[i].technos + "</h2>";
}

// Switch => selon sur ce qu'il clique ca change le fond
document.body.addEventListener("click", (e) => {
  switch (e.target.id) {
    case "javascript":
      document.body.style.background = "yellow";
      break;
    case "php":
      document.body.style.background = "violet";
      break;
    case "python":
      document.body.style.background = "blue";
      break;
    default:
      null;
  }
});

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Methodes String %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

let string2 = "Javascript est un langage orienté objet";

// console.log(typeof "42"); => connaitre type variable
// console.log(eval(parseInt("1") + 2)); => parseint passe de string a int. Eval fait de la concatenation entre les 2
// console.log(isNaN(string)); => est ce que c'est un nombre

// console.log(string2.length);
// console.log(string2[string2.length - 1]);

// console.log(string2.indexOf("langage"));
// console.log(string2.indexOf("x")); // Retourne -1 s'il ne le connait pas

// let newString = string2.slice(20); =>je coupe les 20 premeiers elements et je garde le reste dans new string
// let newString = string2.slice(5, 17); =>je garde ce qu'il y a entre 5 et 17
// console.log(newString);

// console.log(string2.split(" ")); => partout ou tu as un i, tu coupes et ca le stock dans un array

// console.log(string2.toLowerCase());
// console.log(string2.toUpperCase());

// console.log(string2.replace("Javascript", "PHP"));

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Methodes Number %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

let number2 = 42.1234;
let numberString = "42.12 est un chiffre";

// console.log(number2.toFixed(1)); => 1 seul chiffre apres la virgule
// console.log(parseInt("43"));
// console.log(parseInt(numberString));
// console.log(parseFloat(numberString));

// Math
// console.log(Math.PI);
// console.log(Math.round(4.5));
// console.log(Math.floor(4.9)); => arrondi inf
// console.log(Math.ceil(4.1)); => arrondi sup
// console.log(Math.pow(2, 7)); => 2^7
// console.log(Math.sqrt(16));

// console.log(Math.floor(Math.random() * 50));

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Methodes Array %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

let array3 = ["Javascript", "Php", "Python"];
let array4 = ["Ruby", "Solidity"];

// let newArray = array3.concat(array4);
// console.log(newArray);

// let newArray = [...array3, ...array4]; =>Autre maniere de concat
// console.log(newArray);

// console.log(array3.join(' ')); =>casse tout le tableau et entre chaque element du tableau tu vas mettre un espace

// console.log(array3.slice(1)); =Wtu gardes Php et python
// console.log(newArray.slice(3, 5)); =>tu gardes Ruby et solidity

// console.log(array3.indexOf("Python"));

// array3.forEach((x) => console.log(x)); //langugage c'ets le nom on pourrait mettre x

// console.log(array3.every((x) => x == "Php")); //renvoyer false car tous les elements de array3 ne sont pas php 
// console.log(array3.some((x) => x == "Php")); //renvoyer true car un des elements est bien egal a true

// let shift = array3.shift(); =>retire le premier index, le stock variable. JS plus present dans Array3
// console.log(array3);

// console.log(array3.pop()); =>retir dernier element

// const restArray = array3.splice(0, 2, ...array4); à partir de 0 je retire deux elements te je mets les valeurs de array 4 -> array3=[Ruby,Solidatiry,Python]
// console.log(array3);

// IMPORTANT //
let arrayNumber = [4, 74, 28, 12, 1];
// console.log(arrayNumber.reduce((x, y) => x + y)); =>additionne tous les elements du tableau.
arrayNumber.push(17); // => ajoute un element
// console.log(arrayNumber); 

// %%%%%%%%%%% FILTER, SORT, MAP %%%%%%%%%%%%%%%%%%%%

// console.log(arrayNumber.filter((number) => number > 10));

// console.log(arrayNumber.sort()); donne 1 12 17 23 4 ...
// console.log(arrayNumber.sort((a, b) => a - b)); tri par ordre croissant

//  document.body.innerHTML = arrayNumber
//    .map((number) => `<li>${number}</li>`) => Map comme un for each,affiche tous les elements dans une liste 
//    .join(""); => entre chaque tour de MAP on a des espaces et pas des vrigules comme c par default

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Methodes Objects %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// document.body.innerHTML = data
//   .filter((user) => user.pseudo.includes("a"))
//   .sort((a, b) => b.age - a.age)
//   .map(
//     (user) =>
//       `
//     <div class="user-card">
//       <h2>${user.pseudo}</h2>
//       <p>Age : ${user.age} ans</p>
//       <p>Status : ${user.admin ? "Modérateur" : "Membre"}</p>
//     </div>
//   `
//   )
//   .join("");

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Les dates %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

// Date classique
let date = new Date();

// Timestamp
let timestamp = Date.parse(date); //parse => transforme date en timestamp
// console.log(timestamp);

// IsoString
let iso = date.toISOString();

//
function dateParser(chaine) {
  let newDate = new Date(chaine).toLocaleDateString("fr-FR", { //toLocaleDateString on va personnalise notre date
    year: "numeric",
    month: "long",
    day: "numeric",
    // hour: "numeric",
    // minute: "numeric",
  });
  return newDate;
}

//La fonction marche avec tt les formats de date
// console.log(dateParser(date));
// console.log(dateParser(timestamp));
// console.log(dateParser(iso));

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Destructing %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

let moreData = {
  destVar: ["Element 1", "Element 2"],
};

const { destVar } = moreData; // <=> moreData.destVar : bien pour eviter d'avoir a ecrire ca tt le temps

// console.log(moreData.destVar);
// console.log(destVar);

let array5 = [70, 80, 90];
let [x, y, z] = array5;
// console.log(x); 70
// console.log(y); 80
// console.log(z); 90

//on recupere facilement an mois et jour
const dateDestructuring = (chaine) => {
  let newDate = chaine.split("T")[0];
  let [y, m, d] = newDate.split("-");
  return [d, m, y].join("/");
};
console.log(dateDestructuring(iso));

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  DataSet %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

// On peut mettre des dataSet dans la balise HTML et donc les recuperer 
const h3js = document.getElementById("javascript");
// console.log(h3js.dataset.lang);

const h3 = document.querySelectorAll("h3");
// h3.forEach((language) => console.log(language.dataset.lang));

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Regex %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//pour verifier des conditions notament sur une chaine de caractere, voir sur internet 

let mail = "from_s$cratch33@gmail.com";
// console.log(mail.search(/frscceeceom/)); -1 car il ne le trouve pas 0 sinon

// console.log(mail.replace(/from/, "de"));
// console.log(mail.match(/SCratch/i)); si pas de i ca renvoie null car on a pas ca dans mail, avec le i on s'en fout de la case
// console.log(mail.match(/[zug]/)); je lui demande est ce que tu trouves un z un u et un g
// console.log(mail.match(/[12]/));

// Tous les chiffres
// console.log(mail.match(/\d/)); est ce que ca contient bien un nombre

// Matcher toutes les lettres
// console.log(mail.match(/[a-z]/));

//console.log(mail.match(/^[\w_-]+@[\w-]+\.[a-z]{2,4}$/i)); //regex email, si mail bon ca renvoie true

//Regex separateur de millier 
let separator = 265264849;
//console.log(separator.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " "));
