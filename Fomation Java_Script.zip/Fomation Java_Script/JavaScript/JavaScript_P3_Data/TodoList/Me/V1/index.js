const form = document.querySelector("form");
const inputToDo = document.querySelector("#toDo");
const container=document.querySelector(".list");
const arraySpan = []

let inputValue=""


const addThing=(value)=>{

    const newSpan = document.createElement("span");
    newSpan.textContent = `=> ${value}`;

    newSpan.addEventListener("dblclick",(e)=>{
        newSpan.remove()
    })

    container.appendChild(newSpan);
    arraySpan.push(newSpan)
    inputToDo.value=""
}


form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (inputValue){
        addThing(inputValue)
        inputValue=null
    }else{
        alert("veuillez renseigner les champs")
    }

}
)

inputToDo.addEventListener("input",(e)=>{
    inputValue=e.target.value})

