const input=document.querySelector("input")
const form=document.querySelector("form")
const dataToDo=[]
const toDo=document.querySelector("ul")

const recupToDo=()=>{
    dataToDo.push(input.value)
    console.log(dataToDo)
}

const afficher=()=>{
    toDo.innerHTML=dataToDo.map((todo)=>`<li>${todo}</li>`).join("")
}

form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (input.value!=""){
        recupToDo()
        afficher()
        input.value=""
    }else{
        alert("Veuillez renseigner une valeur")
    }

})

// Remove element
toDo.addEventListener("click", (e) => {
    const confirmation = window.confirm("Voulez-vous vraiment supprimer cet élément ?");
    if (confirmation){
        e.target.remove();
        const index = dataToDo.indexOf(e.target.value);
        dataToDo.splice(index, 1);
    }

  });



