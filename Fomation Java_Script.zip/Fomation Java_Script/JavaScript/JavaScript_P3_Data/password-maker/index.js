const dataLowerCase="azertyuiopqsdfghjklmwxcvbn"
const dataUpperCase=dataLowerCase.toUpperCase();
const dataNumbers="0123456789";
const dataSymbols="$^ù*!:;,"
const outputMDP=document.querySelector("#password-output");

function getElementAleatoire(chaine) {

    // Générer un indice aléatoire entre 0 et la longueur du tableau
    const indiceAleatoire = Math.floor(Math.random() * chaine.length);
    // Récupérer l'élément au hasard
    const elementAleatoire = chaine[indiceAleatoire];
    return elementAleatoire;
  }

  
const generatePassWord=()=>{

    //recuperation des données possibles
    let data=[];
    if (lowercase.checked) data.push(dataLowerCase.split(""));
    if (upercase.checked) data.push(dataUpperCase.split(""));
    if (number.checked) data.push(dataNumbers.split(""));
    if (symbols.checked) data.push(dataSymbols.split(""));
    let dataFin = [].concat.apply([], data);
    
    //alerte
    if (dataFin.length===0){
        alert("Selectionnez des critères")
        return
    }
    
    //recuperation nb caracteres
    const nbCaracteres=document.querySelector("#passeword-length");

    //generation du mdp
    let mdp="";
    let i=0;
    //boucle tant qu'on a pas atteint ce nb on ajoute un element de data a mdp
    while (i < nbCaracteres.value) {
        const caracetre=getElementAleatoire(dataFin)
        mdp=mdp+caracetre;
        i++;
      }
      
    //on met le mdp sur le site
    outputMDP.value=mdp;

    //copie le mdp pour l'user
    outputMDP.select();
    navigator.clipboard.writeText(outputMDP.value);
    generateButton.textContent="COpié!"
    setTimeout(()=>{
        generateButton.textContent="Générer un mdp"
    },2000)

}



generateButton.addEventListener('click',generatePassWord);