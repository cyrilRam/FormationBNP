//Declaration Variables
let dataCountry = [];
const rangeValue = document.getElementById("rangeValue");
const inputRange = document.getElementById("inputRange");
const countriesContainer = document.querySelector(".countries-container");
const btnTriCroiss = document.getElementById("minToMax");
const btnTriDeCroiss = document.getElementById("maxToMin");
const btnTriAlpha = document.getElementById("alpha");
const inputSearch = document.getElementById("inputSearch");

let triCroissant = false;
let triDecroissant = false;
let triAlphabetique = false;

// recuperation données
async function fetchCountry() {
  await fetch(`https://restcountries.com/v3.1/all`)
    .then((res) => res.json())
    .then((data) => (dataCountry = data));
  console.log(dataCountry);
  console.log(typeof dataCountry[0]);
}

//fonction affichage
const countryDisplay = () => {
  // dataCountry = triTableau(dataCountry);
  console.log(triAlphabetique);
  countriesContainer.innerHTML = dataCountry
    .filter((country) =>
      country.translations.fra.common
        .toLowerCase()
        .includes(inputSearch.value.toLowerCase())
    )
    .sort((a, b) => {
      if (triCroissant) {
        return a.population - b.population;
      } else if (triDecroissant) {
        return b.population - a.population;
      } else if (triAlphabetique) {
        return a.name.official.localeCompare(b.name.official);
      }
    })
    .slice(0, inputRange.value)
    .map((country) => {
      return `
      <div class="country-card">
        <h3>${country.name.official}<h3>
        <img src="${country.flags.png}" alt="${country.name.official}">
        <h4>${country.capital}<h4>
        <h4>Population : ${country.population}<h4>
      </div>
    `;
    })
    .join("");
};

//MAJ rangeValue
inputRange.addEventListener("input", () => {
  rangeValue.textContent = inputRange.value;
  fetchCountry().then(countryDisplay);
});

inputSearch.addEventListener("input", countryDisplay);

btnTriAlpha.addEventListener("click", () => {
  triCroissant = false;
  triDecroissant = false;
  triAlphabetique = true;
  countryDisplay();
});
btnTriCroiss.addEventListener("click", () => {
  triCroissant = true;
  triDecroissant = false;
  triAlphabetique = false;
  countryDisplay();
});
btnTriDeCroiss.addEventListener("click", () => {
  triCroissant = false;
  triDecroissant = true;
  triAlphabetique = false;
  countryDisplay();
});

//affichage au chargement de la page
fetchCountry().then(countryDisplay);
