//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%   XMLHTTP request -> Lire un fichier txt   %%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//ancienne methode 

function reqListener() {
  // console.log(this.responseText);
}

let req = new XMLHttpRequest();
req.onload = reqListener;
// req.open("get", "data.json", true);
req.open("get", "data.txt", true); //ouvre le fichier data.txt pour recuprer contenu
req.send();

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%     FETCH       %%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//meilleur methode, plus rapide. Fetch = Va chercher

//%%%%%%%%%% GET => Recuperer données %%%%%%%%%%%%%%%%%%%%%%%%%

// fetch("url", "options").then(
//   (response) => {
//     // response ->exploite la reponse
//   }).catch((err) => console.log(err)) //catch si requete pas passée alors tu rattrapes  l'erreur et tu la log
// );

//recuperatiion dans res puis recuperartion du text puis affichage du texte. Data recupere le contenu du then precdent
//ce que tu as recupere dans res je vais l'appeler data
 fetch("data.txt")
   .then((res) => res.text())  
   .then((data) => console.log(data));

// fetch("data.json")
//   .then((res) => res.json())
//   .then((data) => console.log(data));

// %%%%%%%% Personnaliser son Fetch %%%%%%%%
// L'interface Headers vous permet de créer vos propres objets d'en-têtes via le constructeur Headers

const myHeaders = new Headers();

const init = {
  method: "GET", // Get =>Apporte moi données // POST (incremente donées), PUT (MAJ), DELETE (Supprimer données)
  headers: myHeaders,
  mode: "cors",
  cache: "default",
};
fetch("data.json", init).then((res) => res.json());
// .then((data) => console.log(data));

//%%%%%%%%%% Post => Envoyer données %%%%%%%%%%%%%%%%%%%%%%%%%

//On va simuler un serveur
//Il faut installer nodeJS
//Sur le terminal taper les lignes de commande : cd sur le repertoire de ce fichier puis npm init -y puis npm i -g json-ser (pour installer le serveur)
//Créer un fichier db.json qui va etre notre dataBase et mettre dedans {"posts":[]}
//taper sur le terinal json-server --w db.json
//db.json va fonctionner comme un BD distante

let init2 = {
  method: "POST", // POST, PUT, DELETE
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    pseudo: "From Scratch",
    message: "Yo les gens !",
  }),
  mode: "cors",
  credentials: "same-origin",
};

document.querySelector("form").addEventListener("submit", (e) => {
  // e.preventDefault();
  fetch("http://localhost:3000/posts", init2);
});
//pour supprimer message dans init on supprime body, method Delete et dans le fetch faire   fetch("http://localhost:3000/posts"+id, init2);

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%     Asynchrone (executer du code et attent avant de faire ceci) en JS     %%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//%%%%% Methode 1 setTimeOut -> Pas a utiliser %%%%%
setTimeout(() => {
  // console.log("Test !");
}, 2000);

// %%%%%%% Methode 2 : Promise, le then est effectue que quand on a les données du fectch %%%%%%%%%%
// fetch('monlien').then(() => ...) 


// %%%%%%%% Methode 3 function async/await %%%%%%%%%%
async function fetchData() {
  // await fetch('monlien')
  // await maFonction();
  // Execute ensuite... Si  on ne met pas await ca va executer le reste en meme temps que le fetch
}
const fetchData2 = async () => {
  // await fetch('monlien')
  // await maFonction();
  // Execute ensuite...
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%     JSON   %%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

// JSON = format de données

// méthode .json() Elle retourne une promesse qui s'auto-résout en renvoyant le corps de la requête parsée au format JSON.

fetch("data.json")
  .then((res) => res.json()) //on obtient un objet JS
  .then((data) => {
    let settings = JSON.stringify(data);//converti en json
    console.log(JSON.parse(settings)); //transforme JSon en objet havaScript comme avec res.json
  });

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%     WEB API => celles qu'on a de base   %%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//Geolocalisation, canca ...

//%%%%%%%%%%%%%%%%%%%% Client Storage %%%%%%%%%%%%%%%%%%

//------ Local Storage (Stocke données pdt un moment) -----------
//(diff des cookies), plus de stockage que les cookies 4ko contre 10 Mo, de plus les données ne sont pas transmises au prod du site alors que les cookies tout est envoyé au site
//Alller dans inspect App et local storage. 
// Quand je reviens sur le site tout sera encore dispo dans le locl storage


//On va stocker des données
localStorage.data="Je stocke la date"

//on recupere des données
console.log(localStorage.data)

//supprimer data
localStorage.removeItem("data")

//On peut passer que une chaine pas un tableau, il faut le passer en JSON
const obj={
  name:"Denis",
  age:22,
}

localStorage.user=JSON.stringify(obj) //on met au formatJson
console.log(JSON.parse(localStorage.user)) //on remet en format JS

//----------- Session Storage (stocke que pdt le temps d'utilisation, des que page page se ferme ca disparait) -------------------
sessionStorage.dataSett="55px"
sessionStorage.clear() //pour tout nettoyer

//%%%%%%%%%%%%%%%%%%%% Cookies %%%%%%%%%%%%%%%%%%

//les cookies sont envoyées des qu'on fait qlq chose sur le site
document.cookie="User=CIssou" //reste temps session

//Bonne partiue
//path pour que cookie que quand on est sur cette page, secure pour que HTTPS , maxage le temps d'age 
document.cookie="Pseudo=FS;path=/;max-age=450000;secure;samesite;"
