
const header = document.getElementById("header")
const content = document.getElementById("content")

const getJoke=()=>{
//pi qui nous donne une blague au hasard
fetch("https://api.blablagues.net/?rub=blagues")
    .then((res)=>res.json())
    .then((data)=>{
        const partJoke=data.data.content
        //console.log(data) //pour voir les chemins pour aller chercher des choses
        header.textContent= partJoke.text_head
        content.textContent=partJoke.text !== ""
            ?partJoke.text
            :partJoke.text_hidden
        //si diff de "" j'affiche text sinon j'affiche hidden
    })
}

//Lance au chargement page
getJoke()

//quand je clique ca lance
document.body.addEventListener("click",()=>getJoke())