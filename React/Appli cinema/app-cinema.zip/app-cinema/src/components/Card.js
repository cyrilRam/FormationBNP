import React from "react";
import { useEffect, useState } from "react";

const Card = ({ movie, isHome }) => {
  const [genres, setGenres] = useState([]);

  const getGenres = () => {
    setGenres(movie.genre_ids);
    console.log(movie.title);
  };

  const suppFav = () => {
    const existingFavMovies =
      JSON.parse(localStorage.getItem("favMovies")) || [];
    const updatedFavMovies = existingFavMovies.filter(
      (favMovie) => favMovie.id !== movie.id
    );

    localStorage.setItem("favMovies", JSON.stringify(updatedFavMovies));
    // Actualiser la page après la suppression
    window.location.reload();
  };

  const addFav = () => {
    // Récupérer les films existants depuis localStorage ou une liste vide si c'est la première fois
    const existingFavMovies =
      JSON.parse(localStorage.getItem("favMovies")) || [];
    // Vérifier si le film que vous voulez ajouter a le même ID qu'un film existant
    let isMovieAlreadyInFav = false;
    for (const favMovie of existingFavMovies) {
      if (favMovie.id === movie.id) {
        isMovieAlreadyInFav = true;
        break;
      }
    }
    if (!isMovieAlreadyInFav) {
      existingFavMovies.push(movie);
      localStorage.setItem("favMovies", JSON.stringify(existingFavMovies));
    }
  };

  const dateParser = (date) => {
    let newDate = new Date(date).toLocaleDateString("fr-FR", {
      year: "numeric",
      month: "numeric",
      day: "numeric",
    });
    return newDate;
  };

  //UseEffect lors du chargement
  useEffect(() => {
    getGenres();
    console.log(isHome);
  }, []);

  return (
    <div className="card">
      <img
        src={"https://image.tmdb.org/t/p/original" + movie.poster_path}
        alt={"image film " + movie.title}
      />
      <h1>{movie.title}</h1>
      <h3>Sorti le : {dateParser(movie.release_date)}</h3>
      <h4> {movie.vote_average} /10 </h4>
      <div className="genres-containers">
        <ul>
          {genres.map((genre, index) => (
            <li key={index}>{genre}</li>
          ))}
        </ul>
      </div>
      <div className="Synopsis">
        <h4>Synopsis</h4>
        <p>{movie.overview}</p>
      </div>

      <button
        className="fav-button"
        onClick={(e) => (isHome ? addFav() : suppFav())}
      >
        {isHome
          ? "Ajouter à la Liste de Favoris"
          : "Retirer de la Liste de Favoris"}
      </button>
    </div>
  );
};

export default Card;
