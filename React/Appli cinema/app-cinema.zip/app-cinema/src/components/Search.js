import React from "react";
import { useEffect, useState } from "react";
import axios from "axios";
import Card from "./Card";

const Search = ({ home }) => {
  // Composant Search est composé de la partie search ou on va filtrer et trier et de la liste des films

  const [dataMovies, setDataMovies] = useState([]);
  const [dataFavoritesMovies, setDataFavoritesMovies] = useState([]);
  const [inputValueHome, setInputValueHome] = useState("code");
  const [inputValueFav, setInputValueFav] = useState("");
  const [sortGodBad, setSortGodBad] = useState(null);

  /**
   * fonction qui récupère les gilms via l'API. Cette fonction sera appelleé sur la page Home
   */
  const getData = () => {
    if (!inputValueHome) {
      setInputValueHome("code");
    }
    axios
      .get(
        `https://api.themoviedb.org/3/search/movie?api_key=ed82f4c18f2964e75117c2dc65e2161d&query=${inputValueHome}&language=fr-FR`
      )
      .then((res) => setDataMovies(res.data.results));
  };

  /**
   * fonction qui receupere la liste des films en favori via le locage storage
   */
  const getDataFav = () => {
    const existingFavMovies =
      JSON.parse(localStorage.getItem("favMovies")) || [];
    setDataFavoritesMovies(
      existingFavMovies.filter((movie) => movie.title.includes(inputValueFav))
    );
  };

  /**
   * fonction qui se lance quand on va sur une page.
   * Si on est sur home ca va charger les data de l'API sinon celles stockées sur le local storage
   */
  useEffect(() => {
    home ? getData() : getDataFav();
  }, [inputValueHome, inputValueFav]);

  /**
   * A la validation du formulaire on va filtrer les données
   * @param {*} e
   */
  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <div className="movies-container">
      <div className="search">
        <form onSubmit={(e) => handleSubmit(e)}>
          <input
            type="text"
            placeholder="Tapez le nom d'un film"
            onChange={(e) => {
              home
                ? setInputValueHome(e.target.value)
                : setInputValueFav(e.target.value);
            }}
          ></input>
        </form>
        <button className="search-button" onClick={(e) => handleSubmit(e)}>
          Rechercher
        </button>
        <div className="topBut">
          <button className="top" onClick={() => setSortGodBad("goodToBad")}>
            Top
          </button>
          <button className="buttom" onClick={() => setSortGodBad("badToGood")}>
            Buttom
          </button>
        </div>
      </div>
      <div className="card-containers">
        <ul>
          {home
            ? dataMovies
                .sort((a, b) => {
                  if (sortGodBad === "goodToBad")
                    return b.vote_average - a.vote_average;
                  else if (sortGodBad === "badToGood") {
                    return a.vote_average - b.vote_average;
                  }
                })
                .map((movie, index) => (
                  <Card key={index} movie={movie} isHome={home} />
                ))
            : dataFavoritesMovies
                .sort((a, b) => {
                  if (sortGodBad === "goodToBad")
                    return b.vote_average - a.vote_average;
                  else if (sortGodBad === "badToGood") {
                    return a.vote_average - b.vote_average;
                  }
                })
                .map((movie, index) => (
                  <Card key={index} movie={movie} isHome={home} />
                ))}
        </ul>
      </div>
    </div>
  );
};
export default Search;
