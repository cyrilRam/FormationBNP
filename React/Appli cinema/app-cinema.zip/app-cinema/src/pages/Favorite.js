import React from "react";
import Navigation from "../components/Navigation";
import Search from "../components/Search";

const Favorite = () => {
  return (
    <div className="favorite">
      <Navigation />
      <Search home={false} />
    </div>
  );
};

export default Favorite;
